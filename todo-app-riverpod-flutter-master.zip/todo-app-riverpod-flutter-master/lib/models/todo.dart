class Todo{
  int todoId;
  String content;
  bool complete;

  Todo({required this.todoId, required this.content, required this.complete});
}